<?php
$juassi_database_version = '30';
$juassi_program_version = '2.1.0-beta-2';
?>