<?php
	//generic soap client
	class juassi_soap extends nusoap_client {
	}
?>