<?php
	class juassi_soap_server extends nusoap_server {
	}
?>