<?php

	class EventerCalendarVars {
		public $monthNames;
		public $weekDayNames;
		public $dateBoxHorizontalSpace;
		public $dateBoxVerticalSpace;
		public $startingWeekDay;
		public $currentMonth;
		public $currentYear;
		public $nextMonth;
		public $prevMonth;
		public $nextYear;
		public $prevYear;
		public $weekStartDayID;
		public $dateIterator;
		public $numDaysInMonth;
		public $emsTimeStamp;
		public $dateFormatShort;
		public $dateFormatLong;
	}

?>