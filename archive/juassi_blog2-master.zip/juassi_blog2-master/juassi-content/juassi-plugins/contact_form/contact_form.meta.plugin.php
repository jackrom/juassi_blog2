<?php

	/*
		Plugin Meta Data
	*/
	class contact_form {
		function meta_data() {

			$array = array (
				'plugin_name' => 'Contact Form',
				'plugin_description' => 'Default Contact Form Plugin',
				'plugin_update_checker_url' => '',
				'plugin_author' => 'Juan Carlos Reyes C',
				'plugin_author_website' => 'http://www.juassi.com/',
				'plugin_website' => 'http://www.juassi.com/',
				'plugin_version' => '2.0'
			);

			return $array;
		}
	}

?>