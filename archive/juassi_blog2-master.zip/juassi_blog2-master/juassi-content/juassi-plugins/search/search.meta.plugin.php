<?php

	/*
		Plugin Meta Data
	*/
	class search {
	
		function meta_data() {
	
			$array = array (
				'plugin_name' => 'Search',
				'plugin_description' => 'Adds post searching capabilities (MySQL only). Search function coded by Cal Henderson.',
				'plugin_update_checker_url' => '',
				'plugin_author' => 'Juan Carlos Reyes',
				'plugin_author_website' => 'http://www.juassi.com/',
				'plugin_website' => 'http://www.juassi.com/',
				'plugin_version' => '1.1'
			);
	
			return $array;
		}
		
	}

?>
