<!-- Sidebar -->
<div class="col-md-4 sidebar">
	<div class="side-widget">
		<h5><span>Categor&iacute;as</span></h5>
		<ul class="category">
			<?php echo juassi_post_all_cat(); ?>
		</ul>
	</div>

	<div class="clear"></div>
	<div class="space60"></div>

</div>