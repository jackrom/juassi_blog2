<?php

	/*
		Theme Meta Data
	*/
	class classic {
		function meta_data() {
			$array = array (
				'theme_name' => 'Classic',
				'theme_description' => 'The original theme that came with Juassi 1.',
				'them_author' => 'Juan Carlos Reyes C',
				'theme_author_website' => 'http://www.juassi.com/',
				'theme_website' => 'http://www.juassi.com/',
				'theme_version' => '1.0',
			);

			return $array;
		}

	}
?>