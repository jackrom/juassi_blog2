<?php

	/*
		Plugin Meta Data
	*/
	class example_1 {
		function meta_data() {
	
			$array = array (
				'plugin_name' => 'Example 1',
				'plugin_description' => 'An example plugin',
				'plugin_update_checker_url' => '',
				'plugin_author' => 'Author Name',
				'plugin_author_website' => 'http://www.juassi.com/',
				'plugin_website' => 'http://www.juassi.com/',
				'plugin_version' => '1.0'
			);
	
			return $array;
		}
	}

?>