<?php

	/*
		Plugin Meta Data
	*/
	class test {
		function meta_data() {
	
			$array = array (
				'plugin_name' => 'Test',
				'plugin_description' => 'A Test Plugin',
				'plugin_update_checker_url' => 'http://',
				'plugin_author' => 'Juan Carlos Reyes',
				'plugin_author_website' => 'http://www.juassi.com/',
				'plugin_website' => 'http://www.juassi.com/',
				'plugin_version' => '0.1'
			);
	
			return $array;
		}
	}

?>