<?php
/* This file is part of BBClone (The PHP web counter on steroids)
 *
 * CVS File $Id: pt-br.php,v 1.65 2011/12/30 23:03:24 joku Exp $
 *  
 * Copyright (C) 2001-2012, the BBClone Team (see doc/authors.txt for details)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * See doc/copying.txt for details
 */

// The DNS Extensions array
$extensions = array(
"travel" => "Travel",
"asia" => "Asia-Pacific",
"jobs" => "Employment",
"mobi" => "Mobiles",
"cat" => "Catalan",
"tel" => "Contacts",

"ac" => "Ilha Ascen&ccedil;&atilde;o",
"ad" => "Andorra",
"ae" => "Emirados &Aacute;rabes Unidos",
"aero" => "Aero",
"af" => "Afeganist&atilde;o",
"ag" => "Ant&iacute;gua and Barbuda",
"ai" => "Anguilla",
"al" => "Alb&acirc;nia",
"am" => "Arm&ecirc;nia",
"an" => "Antilhas Holandesas",
"ao" => "Angola",
"aq" => "Antarctica",
"ar" => "Argentina",
"arpa" => "Enganos",
"as" => "Samoa Americana",
"at" => "&Aacute;ustria",
"au" => "Australia",
"aw" => "Aruba",
"ax" => "Åland",
"az" => "Azerbaij&atilde;o",
"ba" => "Bosnia e Herzegovina",
"bb" => "Barbados",
"bd" => "Bangladesh",
"be" => "Belgica",
"bf" => "Burkina Faso",
"bg" => "Bulg&aacute;ria",
"bh" => "Bahrain",
"bi" => "Burundi",
"biz" => "Business",
"bj" => "Benin",
"bl" => "São Bartolomeu",
"bm" => "Bermuda",
"bn" => "Brunei",
"bo" => "Bol&iacute;via",
"br" => "Brasil",
"bs" => "Bahamas",
"bt" => "But&atilde;o",
"bv" => "Ilha Bouvet",
"bw" => "Botsuana",
"by" => "Belarus",
"bz" => "Belize",
"ca" => "Canad&aacute;",
"cc" => "Ilhas Cocos",
"cd" => "Congo",
"cf" => "Republica da &Aacute;frica Central",
"cg" => "Congo",
"ch" => "Su&iacute;ca",
"ci" => "Costa do Marfim",
"ck" => "Ilhas Cook",
"cl" => "Chile",
"cm" => "Camar&otilde;es",
"cn" => "China",
"co" => "Col&ocirc;mbia",
"com" => "Comercial",
"coop" => "Coop",
"cr" => "Costa Rica",
"cs" => "Serbia and Montenegro",
"cu" => "Cuba",
"cv" => "Cabo Verde",
"cx" => "Ilhas Natal",
"cy" => "Chipre",
"cz" => "Rep&uacute;blica Czech",
"de" => "Alemanha",
"dj" => "Djibuti",
"dk" => "Dinamarca",
"dm" => "Dominica",
"do" => "Rep&uacute;blica Dominicana",
"dz" => "Alg&eacute;ria",
"ec" => "Equador",
"edu" => "Educacional",
"ee" => "Est&ocirc;nia",
"eg" => "Egito",
"eh" => "Western Sahara",
"er" => "Eritr&eacute;a",
"es" => "Espanha",
"et" => "Eti&oacute;pia",
"eu" => "European Union",
"fi" => "Finl&acirc;ndia",
"fj" => "Fiji",
"fk" => "Ilhas Falkland",
"fm" => "Micronesia",
"fo" => "Ilhas Faroe",
"fr" => "Fran&ccedil;a",
"ga" => "Gab&atilde;o",
"gb" => "Gr&atilde;-Bretanha",
"gd" => "Granada",
"ge" => "Georgia",
"gf" => "Guiana Francesa",
"gg" => "Guernsey",
"gh" => "Gana",
"gi" => "Gibraltar",
"gl" => "Groel&acirc;ndia",
"gm" => "G&acirc;mbia",
"gn" => "Guin&eacute;",
"gov" => "Governo",
"gp" => "Guadalupe",
"gq" => "Guin&eacute; Equatorial",
"gr" => "Grecia",
"gs" => "Ilhas Sul Georgia e Ilhas Sul Sandwich",
"gt" => "Guatemala",
"gu" => "Guam",
"gw" => "Guin&eacute;-Bissau",
"gy" => "Guiana",
"hk" => "Hong Kong",
"hm" => "Ilhas Heard e Mc Donald",
"hn" => "Honduras",
"hr" => "Cro&aacute;cia",
"ht" => "Haiti",
"hu" => "Hungria",
"id" => "Indon&eacute;sia",
"ie" => "Irlanda",
"il" => "Israel",
"im" => "Ilha do Homem",
"in" => "&Iacute;ndia",
"info" => "Information",
"int" => "Organiza&ccedil;&otilde;es Internacionais",
"io" => "Territ&oacute;rio Brit&acirc;nico no Oceano &Iacute;ndico",
"iq" => "Iraque",
"ir" => "Ir&atilde;",
"is" => "Iceland",
"it" => "Italia",
"je" => "Jersey",
"jm" => "Jamaica",
"jo" => "Jord&acirc;nia",
"jp" => "Jap&atilde;o",
"ke" => "Qu&ecirc;nia",
"kg" => "Quirguiquist&atilde;o",
"kh" => "Cambodja",
"ki" => "Kiribati",
"km" => "Comoros",
"kn" => "Saint Kitts and Nevis",
"kp" => "North Korea",
"kr" => "Cor&eacute;ia",
"kw" => "Kuwait",
"ky" => "Ilhas Caimam",
"kz" => "Casaquist&atilde;o",
"la" => "Laos",
"lb" => "L&iacute;bano",
"lc" => "Santa L&uacute;cia",
"li" => "Liechtenstein",
"lk" => "Sri Lanka",
"lr" => "Lib&eacute;ria",
"ls" => "Lesoto",
"lt" => "Lit&ocirc;nia",
"lu" => "Luxemburgo",
"lv" => "Latvia",
"ly" => "L&iacute;bia",
"ma" => "Morrocos",
"mc" => "M&ocirc;naco",
"md" => "Mold&aacute;via",
"me" => "Montenegro",
"mf" => "Saint-Martin",
"mg" => "Madagascar",
"mh" => "Ilhas Marshall",
"mil" => "Militar dos EUA",
"mk" => "Maced&ocirc;nia",
"ml" => "Mali",
"mm" => "Myanmar",
"mn" => "Mong&oacute;lia",
"mo" => "Macau",
"mp" => "Ilhas Mariana do Norte",
"mq" => "Martinica",
"mr" => "Mauritania",
"ms" => "Montserrat",
"mt" => "Malta",
"mu" => "Mauritania",
"museum" => "Museum",
"mv" => "Maldivas",
"mw" => "Malau&iacute;",
"mx" => "M&eacute;xico",
"my" => "Malasia",
"mz" => "Mo&ccedil;ambique",
"na" => "Nam&iacute;bia",
"name" => "Personal",
"nc" => "Nova Caledonia",
"ne" => "N&iacute;ger",
"net" => "Redes",
"nf" => "Ilha Norfolk",
"ng" => "Nigeria",
"ni" => "Nicar&aacute;gua",
"nl" => "Holanda",
"no" => "Noruega",
"np" => "Nepal",
"nr" => "Nauru",
"nu" => "Niue",
"numeric" => "Num&eacute;rico",
"nz" => "Nova Zelandia",
"om" => "Om&atilde;",
"org" => "Organiza&ccedil;&otilde;es",
"pa" => "Panam&aacute;",
"pe" => "Peru",
"pf" => "Polin&eacute;sia Francesa",
"pg" => "Papua Nova Guin&eacute;",
"ph" => "Filipinas",
"pk" => "Paquist&atilde;o",
"pl" => "Pol&ocirc;nia",
"pm" => "St. Pierre e Miquelon",
"pn" => "Pitcairn",
"pr" => "Porto Rico",
"pro" => "Professional",
"ps" => "Palestina",
"pt" => "Portugal",
"pw" => "Palau",
"py" => "Paraguai",
"qa" => "Qatar",
"re" => "Reuni&atilde;o",
"ro" => "Rom&ecirc;nia",
"rs" => "Serbia",
"ru" => "Federa&ccedil;&atilde;o Russa",
"rw" => "Ruanda",
"sa" => "Ar&aacute;bia Saudita",
"sb" => "Ilhas Salom&atilde;o",
"sc" => "Seycheles",
"sd" => "Sud&atilde;o",
"se" => "Su&eacute;cia",
"sg" => "Singapura",
"sh" => "St. Helena",
"si" => "Eslov&ecirc;nia",
"sj" => "Ilhas Svalbard e Jan Mayen",
"sk" => "Eslov&aacute;quia",
"sl" => "Serra Leoa",
"sm" => "San Marino",
"sn" => "Senegal",
"so" => "Som&aacute;lia",
"sr" => "Suriname",
"st" => "S&atilde;o Tom&eacute; e Pr&eacute;ncipe",
"su" => "Uni&atilde;o Sovi&eacute;tica",
"sv" => "El Salvador",
"sy" => "S&iacute;ria",
"sz" => "Suazilandia",
"tc" => "Ilhas Turks e Caicos",
"td" => "Chade",
"tf" => "Territ&oacute;rio do Sul da Fran&ccedil;a",
"tg" => "Togo",
"th" => "Tail&acirc;ndia",
"tj" => "Tajiquist&atilde;o",
"tk" => "Tokelau",
"tl" => "Timor Leste",
"tm" => "Turcomenist&atilde;o",
"tn" => "Tun&iacute;sia",
"to" => "Tonga",
"tp" => "Timor Leste",
"tr" => "Turquia",
"tt" => "Trinidad e Tobago",
"tv" => "Tuvalu",
"tw" => "Taiwan",
"tz" => "Tanz&acirc;nia",
"ua" => "Ucr&acirc;nia",
"ug" => "Uganda",
"uk" => "Reino Unido",
"um" => "Ilhas menores dos EUA",
"unknown" => "Desconhecido",
"us" => "Estados Unidos",
"uy" => "Uruguai",
"uz" => "Usbequist&atilde;o",
"va" => "Estado do Vaticano",
"vc" => "St. Vincent e Grenadines",
"ve" => "Venezuela",
"vg" => "Ilhas Virges (UK)",
"vi" => "Ilhas Virgens (EUA)",
"vn" => "Vietn&atilde;",
"vu" => "Vanuatu",
"wf" => "Ilhas Wallis e Futuna",
"ws" => "Samoa",
"ye" => "I&ecirc;men",
"yt" => "Mayotte",
"yu" => "Serbia and Montenegro",
"za" => "&Aacute;frica do Sul",
"zm" => "Z&acirc;mbia",
"zr" => "Zaire",
"zw" => "Zimb&aacute;bue",
);

// The main Translation array
$translation = array(
// Specific charset
"global_charset" => "utf-8",

// Global translation
"global_titlebar"=> "Statistics for %SERVER generated on %DATE",
"global_bbclone_copyright" => "O time BBClone - Distribu&iacute;do sob a Licen&ccedil;a",
"global_last_reset" => "Statistics last reset on",
"global_yes" => "sim",
"global_no" => "n&atilde;o",

// The error messages
"error_cannot_see_config" =>
"N&atilde;o &eacute; permitido ver a configura&ccedil;&atilde;o do BBClone configuration neste servidor.",

// Date format (used with date())
"global_time_format" => "M jS, H:i:s",
"global_day_format" => "l F jS, Y",
"global_hours_format" => "l F jS, G:00",
"global_month_format" => "F Y",

// Miscellaneous translations
"misc_other" => "Outro",
"misc_unknown" => "Desconhecido",
"misc_second_unit" => "s",
"misc_ignored" => "Ignorado",

// The Navigation Bar
"navbar_main_site" => "P&aacute;gina Principal",
"navbar_configuration" => "Configura&ccedil;&atilde;o",
"navbar_global_stats" => "Estat&iacute;sticas Globais",
"navbar_detailed_stats" => "Estat&iacute;sticas Detalhadas",
"navbar_time_stats" => "Estat&iacute;sticas Cronol&oacute;gicas",
"navbar_language" => "Language",
"navbar_go" => "Go",

// Detailed stats words
"dstat_id" => "ID",
"dstat_time" => "Tempo",
"dstat_visits" => "Visitas",
"dstat_extension" => "Extens&atilde;o",
"dstat_dns" => "Hostname",
"dstat_from" => "De",
"dstat_os" => "OS",
"dstat_browser" => "Navegador",
"dstat_visible_rows" => "Acessos vis&iacute;veis",
"dstat_green_rows" => "linhas verdes",
"dstat_blue_rows" => "linhas azuis",
"dstat_red_rows" => "linhas vermelhas",
"dstat_search" => "Busca",
"dstat_last_page" => "&uacute;ltima p&aacute;gina",
"dstat_last_visit" => "&uacute;ltima visita",
"dstat_robots" => "rob&ocirc;s",
"dstat_my_visit" => "Visits from your IP",
"dstat_no_data" => "No data available",
"dstat_prx" => "Proxy Server",
"dstat_ip" => "IP Address",
"dstat_user_agent" => "User Agent",
"dstat_nr" => "Nr",
"dstat_pages" => "Pages",
"dstat_visit_length" => "Visit Length",
"dstat_reloads" => "Reloads",
"dstat_whois_information" => "Look up information on this IP Adress",

// Global stats words
"gstat_accesses" => "Acessos",
"gstat_total_visits" => "Total visitas",
"gstat_total_unique" => "Total &uacute;nicas",
"gstat_operating_systems" => "Sistemas operacionais: %d Mais",
"gstat_browsers" => "Navegadores: %d Mais",
"gstat_extensions" => "Extens&otilde;es: %d Mais",
"gstat_robots" => "Rob&ocirc;s: %d Mais",
"gstat_pages" => "P&aacute;ginas Visitadas: %d Mais",
"gstat_origins" => "Origens: %d Mais",
"gstat_hosts" => "Top %d Hosts",
"gstat_keys" => "Top %d Keywords",
"gstat_total" => "Total",
"gstat_not_specified" => "N&atilde;o especificado",

// Time stats words
"tstat_su" => "Dom",
"tstat_mo" => "Seg",
"tstat_tu" => "Ter",
"tstat_we" => "Qua",
"tstat_th" => "Qui",
"tstat_fr" => "Sex",
"tstat_sa" => "S&aacute;b",

"tstat_full_su" => "Sunday",
"tstat_full_mo" => "Monday",
"tstat_full_tu" => "Tuesday",
"tstat_full_we" => "Wednesday",
"tstat_full_th" => "Thursday",
"tstat_full_fr" => "Friday",
"tstat_full_sa" => "Saturday",

"tstat_jan" => "Jan",
"tstat_feb" => "Feb",
"tstat_mar" => "Mar",
"tstat_apr" => "Abr",
"tstat_may" => "Mai",
"tstat_jun" => "Jun",
"tstat_jul" => "Jul",
"tstat_aug" => "Ago",
"tstat_sep" => "Set",
"tstat_oct" => "Out",
"tstat_nov" => "Nov",
"tstat_dec" => "Dez",

"tstat_full_jan" => "January",
"tstat_full_feb" => "February",
"tstat_full_mar" => "March",
"tstat_full_apr" => "April",
"tstat_full_may" => "May",
"tstat_full_jun" => "June",
"tstat_full_jul" => "July",
"tstat_full_aug" => "August",
"tstat_full_sep" => "September",
"tstat_full_oct" => "October",
"tstat_full_nov" => "November",
"tstat_full_dec" => "December",

"tstat_last_day" => "&Uacute;ltimo dia",
"tstat_last_week" => "&Uacute;ltima semana",
"tstat_last_month" => "&Uacute;ltimo m&ecirc;s",
"tstat_last_year" => "&Uacute;ltimo ano",
"tstat_average" => "Average",

// Loadtime notice
"generated" => "page generated in ",
"seconds" => " seconds",

// Configuration page words and sentences

"config_variable_name" => "Nome da Vari&aacute;vel",
"config_variable_value" => "Valor da Vari&aacute;vel",
"config_explanations" => "Explana&ccedil;&otilde;es",

"config_BBC_MAINSITE" =>
"If this variable has been set, a link to the specified location will be
generated. The default value is pointing to the parent directory. In case your
main site is located elsewhere, you probably want to adjust the value to suit
your needs.<br />
Examples:<br />
\$BBC_MAINSITE = &quot;http://www.myserver.com/&quot;<br />
\$BBC_MAINSITE = &quot;..&quot;<br />
\$BBC_MAINSITE = &quot;&quot;;",

"config_BBC_SHOW_CONFIG" =>
"BBClone defaults to revealing the stats' settings. In case this behavior isn't
desired you can deny access to it by deactivating the option.<br />
Examples:<br />
\$BBC_SHOW_CONFIG = 1;<br />
\$BBC_SHOW_CONFIG = &quot;&quot;;",

"config_BBC_TITLEBAR" =>
"O t&iacute;tulo aparecendo dentro da barra de t&iacute;tulo presente em todas p&aacute;ginas do BBClone.<br />
Vari&aacute;veis reconhec&iacute;veis s&atilde;o:<br />
<ul>
<li>%SERVER: nome do servidor,</li>
<li>%DATE: a data corrente.</li>
</ul>
HTML tags s&atilde;o tamb&eacute;m permitidas.<br />
Examples:<br />
\$BBC_TITLEBAR = &quot;Statistics for %SERVER generated the %DATE&quot;;<br />
\$BBC_TITLEBAR = &quot;My stats from %DATE look like this:&quot;;
<br />",

"config_BBC_LANGUAGE" =>
"BBClone's default language, in case it hasn't been specified by the browser.
The following languages are supported:
<p>ar, bg, bs, ca, cs, da, de, el, en, es, fi, fr, hu, id, it, ja, ko, lt, mk, nb, nl, pl, pt pt-br, ro, ru,
sk, sl, sv, th, tr, ua, zh-cn and zh-tw</p>",

"config_BBC_MAXTIME" =>
"This variable defines the length of an unique visit in seconds. Each hit from
the same visitor within this period will be considered as one visit, as long as
two successive hits don't exceed the specified limit. Default is the de facto
web standard of 30 minutes (1800 seconds), but depending on your needs you may
wish to assign a different value.<br />
Examples:<br />
\$BBC_MAXTIME = 0;<br />
\$BBC_MAXTIME = 1800;",

"config_BBC_MAXVISIBLE" =>
"How many entries you want to have listed in the detailed stats? The default
value is 100. It's recommended not to set it higher than 500 to avoid too heavy
load.",

"config_BBC_DETAILED_STAT_FIELDS" =>
"The variable \$BBC_DETAILED_STAT_FIELDS determines the columns to be displayed
in the detailed statistics. Possible columns are:
<ul>
<li>id&nbsp;=&gt;&nbsp;The x-th visitor since you've started counting</li>
<li>time&nbsp;=&gt;&nbsp;The time at which the last hit was registerred</li>
<li>visits&nbsp;=&gt;&nbsp;The hits of one unique visitor</li>
<li>dns&nbsp;=&gt;&nbsp;Visitor's hostname</li>
<li>ip&nbsp;=&gt;&nbsp;Visitor's IP address</li>
<li>os&nbsp;=&gt;&nbsp;the operating system (if available and/or no robot)</li>
<li>browser&nbsp;=&gt;&nbsp;The software used for establishing the connection
</li>
<li>ext&nbsp;=&gt;&nbsp;Visitor's country or extension</li>
<li>referer&nbsp;=&gt;&nbsp;The link from which a visitor came (if available)</li>
<li>page&nbsp;=&gt;&nbsp;The last visited page</li>
<li>search&nbsp;=&gt;&nbsp;The search query a visitor used (if available)</li>
</ul>
The same order you've arranged the columns will be used for display.<br />
Examples:<br />
\$BBC_DETAILED_STAT_FIELDS = &quot;id, time, visits, ip, ext, os, browser&quot;;
<br />
\$BBC_DETAILED_STAT_FIELDS = &quot;date, ext, browser, os, ip&quot;;<br />",

"config_BBC_TIME_OFFSET" =>
"In case the server time doesn't match your local timezone, you can adjust the
time in minutes by using this switch. Negative values will set back the time,
positive ones will set it forth.<br />
Examples:<br />
\$BBC_TIME_OFFSET = 300;<br />
\$BBC_TIME_OFFSET = -300;<br />
\$BBC_TIME_OFFSET = 0;",

"config_BBC_NO_DNS" =>
"This options defines, whether IP addresses should be resolved to hostnames or
not. While hostnames tell a lot more about the visitor, resolving them may
considerably slow down your site, if the DNS servers used are slow, limited in
their capacity or otherwise unreliable. Setting this variable may solve the
problem.<br />
Examples:<br />
\$BBC_NO_DNS = 1;<br />
\$BBC_NO_DNS = &quot;&quot;;",

"config_BBC_NO_HITS" =>
"BBClone's default is to show hits in the time stats, because it gives a quite
useful Impression from the actual server load. If, however, you prefer to use
unique visits as base for your time stats, you can change the way of counting
by setting this variable.<br />
Examples:<br />
\$BBC_NO_HITS = 1;<br />
\$BBC_NO_HITS = &quot;&quot;;",

"config_BBC_IGNORE_IP" =>
"This option can be used to exclude particular IP addresses or address ranges
from counting. In case you want to add several expressions use a comma as
separator.<br />
Examples:<br />
\$BBC_IGNORE_IP = &quot;127., 192.168.&quot;;<br />
\$BBC_IGNORE_IP = &quot;&quot;;",

"config_BBC_IGNORE_REFER" =>
"In case you don't want to have particular referrers from your visitors listed
in your ranking or detailed stats, you can specify one or more keywords used
for blocking if a referrer matches up against them. If you use more keywords,
please use a comma as separator.<br />
Examples:<br />
\$BBC_IGNORE_REFER = &quot;spambot.org, .escort.&quot;;<br />
\$BBC_IGNORE_REFER = &quot;&quot;;",

"config_BBC_IGNORE_BOTS" =>
"You can use this option to determine the treatment of robots. The default is
to ignore them in the top hosts ranking but leave them in the remaining
stats. If you don't want to see any robots at all you can set this option to
&quot;2&quot;, then only human visits will be taken into account.<br />
Examples:<br />
\$BBC_IGNORE_BOTS = 2;<br />
\$BBC_IGNORE_BOTS = 1;<br />
\$BBC_IGNORE_BOTS = &quot;&quot;;",

"config_BBC_IGNORE_AGENT" =>
"This option defines how BBClone tells one visitor from another. Default is to
use the IP address only, which provides realistic figures in most cases. If,
however, your visitors often are hidden behind proxy servers, deactivation of
this option could provide more realistic figures, since a new visitor will be
assumed by the time the user agent has changed.<br />
Examples:<br />
\$BBC_IGNORE_AGENT = 1;<br />
\$BBC_IGNORE_AGENT = &quot;&quot;;",

"config_BBC_KILL_STATS" =>
"Whenever you wish to reset your stats you can activate this switch and have
them deleted by the next visit. Don't forget to deactivate it afterwards, else
you'll probably experience unusually low traffic ;).<br />
Examples:<br />
\$BBC_KILL_STATS = 1;<br />
\$BBC_KILL_STATS = &quot;&quot;;",

"config_BBC_PURGE_SINGLE" =>
"Host and referrer stats can generate a huge amount of data, however mostly
caused by one time visitors. By enabling this switch you can purge these
entries and considerably shrink access.php in its size without affecting your
actual visible host and referrer ranking. The amount of hits will be added to
the &quot;not_specified&quot; entries to keep the overall score intact.<br />
Examples:<br />
\$BBC_PURGE_SINGLE = 1;<br />
\$BBC_PURGE_SINGLE = &quot;&quot;;"

);
?>
