<?php

//MySQL Database Settings
define("DB_USER", "jcarlos");
define("DB_PASSWORD", "6662115Jc");
define("DB_SERVER", "localhost");
define("DB_NAME", "jcarlos_blog");

//POP3 Settings
define("POP3_USER", "yensi@yensi.com.ve");
define("POP3_PASSWORD", "6662115JcRc");
define("POP3_SERVER", "mail.paneldehosting.com");

//SMTP Settings
define("SMTP_DO_AUTHORIZATION", true);
define("SMTP_USER", "yensi@yensi.com.ve");
define("SMTP_PASSWORD", "6662115JcRc");
define("SMTP_SERVER", "mail.paneldehosting.com");

//SMTP User Settings
define("EMAIL_FROM_ADDRESS", "yensi@yensi.com.ve");
define("EMAIL_FROM_NAME", "Yensi C Reyes C");

//Mail settings
define("MESSAGES_PER_PAGE", 30);
?>
