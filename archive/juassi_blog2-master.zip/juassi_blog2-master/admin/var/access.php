<?php
global $access;
$access =
  array(
    "time" =>
    array(
      "reset" => 1357948493, "last" => 1388995671, 
      "hour" =>
      array(
        5, 0, 0, 0, 0, 1, 10, 3, 2, 0, 0, 0, 0, 0, 0, 0, 4, 2, 0, 0, 0, 0, 0, 0
      ),
      "wday" =>
      array(
        7, 21, 0, 0, 0, 5, 0
      ),
      "day" =>
      array(
        0, 0, 5, 0, 7, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ),
      "month" =>
      array(
        33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1
      )
    ),
    "page" =>
    array(
      "Estadist&amp;iacute;cas Globales" =>
      array(
        "count" => 101, "uri" => "/"
      )
    ),
    "stat" =>
    array(
      "totalvisits" => 101, "totalcount" => 30, 
      "ext" =>
      array(
        "unknown" => 30
      ),
      "browser" =>
      array(
        "other" => 30
      ),
      "os" =>
      array(
        "other" => 30
      )
    ),
    "referer" =>
    array(
      "not_specified" => 30
    ),
    "host" =>
    array(
      "localhost" => 30
    ),
    "bugs" =>
    array(
      "ref_fix" => 1
    )
  );
?>