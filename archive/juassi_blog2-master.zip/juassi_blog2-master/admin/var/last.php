<?php
global $last;
$last =
  array(
    "pages" =>
    array(
      "Estadist&amp;iacute;cas Globales"
    ),
    "traffic" =>
    array(
      array(
        "time" => 978310011, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 21, 
        "views" =>
        array(
          "1374713057|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1357949133, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 12, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 1, 
        "views" =>
        array(
          "1357948774|0|12"
        ),
        "search" => "-", "off" => 11
      ),
      array(
        "time" => 1357952110, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 2, 
        "views" =>
        array(
          "1357952110|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1357955428, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 3, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 3, 
        "views" =>
        array(
          "1357955392|0|3"
        ),
        "search" => "-", "off" => 2
      ),
      array(
        "time" => 1358597045, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 4, 
        "views" =>
        array(
          "1358597045|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1362491662, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 5, 
        "views" =>
        array(
          "1362491617|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1369852317, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 6, 
        "views" =>
        array(
          "1369852252|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1374253138, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 6, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 7, 
        "views" =>
        array(
          "1374251391|0|6"
        ),
        "search" => "-", "off" => 5
      ),
      array(
        "time" => 1374272627, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 8, 
        "views" =>
        array(
          "1374272627|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374287213, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 9, 
        "views" =>
        array(
          "1374287213|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374289933, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 10, 
        "views" =>
        array(
          "1374289159|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1374294922, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 11, 
        "views" =>
        array(
          "1374294922|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374331484, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 4, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 12, 
        "views" =>
        array(
          "1374331180|0|4"
        ),
        "search" => "-", "off" => 3
      ),
      array(
        "time" => 1374337637, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 9, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 13, 
        "views" =>
        array(
          "1374337315|0|9"
        ),
        "search" => "-", "off" => 8
      ),
      array(
        "time" => 1374339678, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 14, 
        "views" =>
        array(
          "1374339541|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1374354527, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 15, 
        "views" =>
        array(
          "1374354527|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374369306, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 16, 
        "views" =>
        array(
          "1374369306|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374379750, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 4, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 17, 
        "views" =>
        array(
          "1374377692|0|4"
        ),
        "search" => "-", "off" => 3
      ),
      array(
        "time" => 1374425331, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 18, 
        "views" =>
        array(
          "1374425331|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374446514, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 19, 
        "views" =>
        array(
          "1374446514|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1374589487, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 20, 
        "views" =>
        array(
          "1374589487|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1383765439, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 22, 
        "views" =>
        array(
          "1383765285|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1386010144, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 23, 
        "views" =>
        array(
          "1386010144|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1388718123, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 3, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 24, 
        "views" =>
        array(
          "1388717806|0|3"
        ),
        "search" => "-", "off" => 2
      ),
      array(
        "time" => 1388763507, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 2, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 25, 
        "views" =>
        array(
          "1388763448|0|2"
        ),
        "search" => "-", "off" => 1
      ),
      array(
        "time" => 1388892637, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 1, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 26, 
        "views" =>
        array(
          "1388892637|0|1"
        ),
        "search" => "-"
      ),
      array(
        "time" => 1388941271, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 6, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 27, 
        "views" =>
        array(
          "1388939101|0|6"
        ),
        "search" => "-", "off" => 5
      ),
      array(
        "time" => 1388968625, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 5, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 28, 
        "views" =>
        array(
          "1388966489|0|5"
        ),
        "search" => "-", "off" => 4
      ),
      array(
        "time" => 1388992047, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 13, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 29, 
        "views" =>
        array(
          "1388986761|0|13"
        ),
        "search" => "-", "off" => 12
      ),
      array(
        "time" => 1388995671, "prx_ip" => "unknown", "ip" => "127.0.0.1", "dns" => "localhost", "agent" => "unknown", "referer" => "unknown", "page" => 0, "visits" => 3, "browser" => "other", "os" => "other", "ext" => "unknown", "id" => 30, 
        "views" =>
        array(
          "1388994612|0|3"
        ),
        "search" => "-", "off" => 2
      )
    )
  );
?>