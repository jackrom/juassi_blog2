<?php
$server_link = mysql_connect("localhost", "jcarlos", "6662115Jc") or die(mysql_error());
$db_link = mysql_select_db("jcarlos_blog") or die(mysql_error());
?>
