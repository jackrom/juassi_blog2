<?php
	include('include/admin-header.php');
	juassi_set_admin_title('Index Admin');
	juassi_set_in_admin(true);
        include('include/html-header.php');
?>

<?php
        
	if ($message = juassi_admin_upgrade_message()) {
		echo juassi_admin_message($message);
	}
	
	if (is_readable("../admin/constantes.php")) require_once("../admin/constantes.php");
	else exit("ERROR: Imposible abrir constantes.php");

	foreach (array($JUASSI_CONFIG_FILE, $JUASSI_LIB_PATH."selectlang.php", $JUASSI_ACCESS_FILE) as $i) {
            if (is_readable($i)) require_once($i);
            else exit(juassi_msg($i));
        }
	

?>

<div class="row-fluid">
    <div class="span7">
        <h3 class="heading">Estadisticas Generales <small>&Uacute;ltimos Datos</small></h3>
        <ul class="ov_boxes">
                <li>
                        <div class="p_bar_up p_canvas">2,4,9,7,12,8,16</div>
                        <div class="ov_text">
                                <strong><?php echo juassi_histcalc($access['time']['month']); ?></strong>
                                <?php echo $translation['tstat_last_year']; ?>
                        </div>
                </li>
                <li>
                        <div class="p_bar_down p_canvas">20,15,18,14,10,13,9,7</div>
                        <div class="ov_text">
                                <strong><?php echo juassi_histcalc($access['time']['day']); ?></strong>
                                <?php echo $translation['tstat_last_month']; ?>
                        </div>
                </li>
                <li>
                        <div class="p_line_up p_canvas">3,5,9,7,12,8,16</div>
                        <div class="ov_text">
                                <strong><?php echo juassi_histcalc($access['time']['wday']); ?></strong>
                                <?php echo $translation['tstat_last_week']; ?>
                        </div>
                </li>
                <li>
                        <div class="p_line_down p_canvas">20,16,14,18,15,14,14,13,12,10,10,8</div>
                        <div class="ov_text">
                                <strong><?php echo juassi_histcalc($access['time']['hour']);  ?></strong>
                                <?php echo $translation['tstat_last_day']; ?>
                        </div>
                </li>
                <li>
                        <div class="p_line_up p_canvas">3,5,9,7,12,8,16</div>
                        <div class="ov_text">
                                <strong><?php echo $access['stat']['totalvisits']; ?></strong>
                                <?php echo $translation['gstat_total_visits']; ?>
                        </div>
                </li>
                <li>
                        <div class="p_line_down p_canvas">20,16,14,18,15,14,14,13,12,10,10,8</div>
                        <div class="ov_text">
                                <strong><?php echo $access['stat']['totalcount']; ?></strong>
                                <?php echo $translation['gstat_total_unique']; ?>
                        </div>
                </li>
        </ul>
    </div>
    
        <?php echo juassi_show_os(); ?>
   
</div>

<div class="row-fluid">
<div class="span5">
        <h3 class="heading">Visitors by Country <small>&Uacute;ltimo mes</small></h3>
        <div id="fl_2" style="height:200px;width:80%;margin:50px auto 0"></div>
</div>
<div class="span7">
        <div class="heading clearfix">
                <h3 class="pull-left"><?php echo $translation['tstat_last_week']; ?></h3>
                <span class="pull-right label label-info ttip_t" title="Visitas Diarias ultima semana">Info</span>
        </div>
        <div id="fl_a" style="width:100%;margin:40px auto 10px 80px;"><img src="lastDias.png" /></div>
        
</div>
</div>


<div class="row-fluid">
<div class="span8">
        <h3 class="heading">Calendar</h3>
        <div id="calendar"></div>
</div>
</div>
             
<script src="../juassi-resources/javascript/jquery.min.js"></script>
<!-- smart resize event -->
<script src="../juassi-resources/javascript/jquery.debouncedresize.min.js"></script>
<!-- hidden elements width/height -->
<script src="../juassi-resources/javascript/jquery.actual.min.js"></script>
<!-- js cookie plugin -->
<script src="../juassi-resources/javascript/jquery.cookie.min.js"></script>
<!-- main bootstrap js -->
<script src="../juassi-resources/bootstrap/js/bootstrap.min.js"></script>
<!-- tooltips -->
<script src="../juassi-resources/lib/qtip2/jquery.qtip.min.js"></script>
<!-- jBreadcrumbs -->
<script src="../juassi-resources/lib/jBreadcrumbs/js/jquery.jBreadCrumb.1.1.min.js"></script>
<!-- lightbox -->
<script src="../juassi-resources/lib/colorbox/jquery.colorbox.min.js"></script>
<!-- fix for ios orientation change -->
<script src="../juassi-resources/javascript/ios-orientationchange-fix.js"></script>
<!-- scrollbar -->
<script src="../juassi-resources/lib/antiscroll/antiscroll.js"></script>
<script src="../juassi-resources/lib/antiscroll/jquery-mousewheel.js"></script>
<!-- common functions -->
<script src="../juassi-resources/javascript/gebo_common.js"></script>

<script src="../juassi-resources/lib/jquery-ui/jquery-ui-1.8.20.custom.min.js"></script>
<!-- touch events for jquery ui-->
<script src="../juassi-resources/javascript/forms/jquery.ui.touch-punch.min.js"></script>
<!-- multi-column layout -->
<script src="../juassi-resources/javascript/jquery.imagesloaded.min.js"></script>
<script src="../juassi-resources/javascript/jquery.wookmark.js"></script>
<!-- responsive table -->
<script src="../juassi-resources/javascript/jquery.mediaTable.min.js"></script>
<!-- small charts -->
<script src="../juassi-resources/javascript/jquery.peity.min.js"></script>
<!-- charts -->
<script src="../juassi-resources/lib/flot/jquery.flot.min.js"></script>
<script src="../juassi-resources/lib/flot/jquery.flot.resize.min.js"></script>
<script src="../juassi-resources/lib/flot/jquery.flot.pie.min.js"></script>
<!-- calendar -->
<script src="../juassi-resources/lib/fullcalendar/fullcalendar.min.js"></script>
<!-- sortable/filterable list -->
<script src="../juassi-resources/lib/list_js/list.min.js"></script>
<script src="../juassi-resources/lib/list_js/plugins/paging/list.paging.min.js"></script>
<!-- dashboard functions -->
<!--<script src="../juassi-resources/javascript/gebo_dashboard.js"></script>-->

<script>
/* [ ---- Gebo Admin Panel - dashboard ---- ] */

	$(document).ready(function() {
		//* small charts
		gebo_peity.init();
		//* charts
		gebo_charts.fl_2();
		//* sortable/searchable list
		gebo_flist.init();
		//* calendar
		gebo_calendar.init();
		//* responsive table
		gebo_media_table.init();
		//* resize elements on window resize
		var lastWindowHeight = $(window).height();
		var lastWindowWidth = $(window).width();
		$(window).on("debouncedresize",function() {
			if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
				lastWindowHeight = $(window).height();
				lastWindowWidth = $(window).width();
				//* rebuild calendar
				$('#calendar').fullCalendar('render');
			}
		});
		//* small gallery grid
        gebo_gal_grid.small();
	});
	
	//* small charts
	gebo_peity = {
		init: function() {
			$.fn.peity.defaults.line = {
				strokeWidth: 1,
				delimeter: ",",
				height: 32,
				max: null,
				min: 0,
				width: 50
			};
			$.fn.peity.defaults.bar = {
				delimeter: ",",
				height: 32,
				max: null,
				min: 0,
				width: 50
			};
			$(".p_bar_up").peity("bar",{
				colour: "#6cc334"
			});
			$(".p_bar_down").peity("bar",{
				colour: "#e11b28"
			});
			$(".p_line_up").peity("line",{
				colour: "#b4dbeb",
				strokeColour: "#3ca0ca"
			});
			$(".p_line_down").peity("line",{
				colour: "#f7bfc3",
				strokeColour: "#e11b28"
			});
		}
	};

	//* charts
    gebo_charts = {
        
        fl_2 : function() {
            // Setup the placeholder reference
            elem = $('#fl_2');
           
			var data = [
                                    <?php
                                        $estadisticas = $access['stat']['ext'];
                                        reset($estadisticas);
                                        while (list($clave, $valor) = each($estadisticas)) {
                                            echo "{label:\"".$clave."\", data:".$valor."},";
                                        }
                                   ?>
                            
				
			];
			
			// Setup the flot chart using our data
            $.plot(elem, data,         
                {
					label: "Visitors by Location",
                    series: {
                        pie: {
                            show: true,
							highlight: {
								opacity: 0.2
							}
                        }
                    },
                    grid: {
                        hoverable: true,
                        clickable: true
                    },
					//colors: [ "#b3d3e8", "#8cbddd", "#65a6d1", "#3e8fc5", "#3073a0", "#245779", "#183b52" ]
					colors: [ "#b4dbeb", "#8cc7e0", "#64b4d5", "#3ca0ca", "#2d83a6", "#22637e", "#174356", "#0c242e" ]
                }
            );
            // Create a tooltip on our chart
            elem.qtip({
                prerender: true,
                content: 'Loading...', // Use a loading message primarily
                position: {
                    viewport: $(window), // Keep it visible within the window if possible
                    target: 'mouse', // Position it in relation to the mouse
                    adjust: { x: 7 } // ...but adjust it a bit so it doesn't overlap it.
                },
                show: false, // We'll show it programatically, so no show event is needed
                style: {
                    classes: 'ui-tooltip-shadow ui-tooltip-tipsy',
                    tip: false // Remove the default tip.
                }
            });
         
            // Bind the plot hover
            elem.on('plothover', function(event, pos, obj) {
                
                // Grab the API reference
                var self = $(this),
                    api = $(this).qtip(),
                    previousPoint, content,
         
                // Setup a visually pleasing rounding function
                round = function(x) { return Math.round(x * 1000) / 1000; };
         
                // If we weren't passed the item object, hide the tooltip and remove cached point data
                if(!obj) {
                    api.cache.point = false;
                    return api.hide(event);
                }
         
                // Proceed only if the data point has changed
                previousPoint = api.cache.point;
                if(previousPoint !== obj.seriesIndex)
                {
                    percent = parseFloat(obj.series.percent).toFixed(2);
                    // Update the cached point data
                    api.cache.point = obj.seriesIndex;
                    // Setup new content
                    content = obj.series.label + ' ( ' + percent + '% )';
                    // Update the tooltip content
                    api.set('content.text', content);
                    // Make sure we don't get problems with animations
                    //api.elements.tooltip.stop(1, 1);
                    // Show the tooltip, passing the coordinates
                    api.show(pos);
                }
            });
        }
    };

	//* filterable list
	gebo_flist = {
		init: function(){
			//*typeahead
			var list_source = [];
			$('.user_list li').each(function(){
				var search_name = $(this).find('.sl_name').text();
				//var search_email = $(this).find('.sl_email').text();
				list_source.push(search_name);
			});
			$('.user-list-search').typeahead({source: list_source, items:5});
			
			var pagingOptions = {};
			var options = {
				valueNames: [ 'sl_name', 'sl_status', 'sl_email' ],
				page: 10,
				plugins: [
					[ 'paging', {
						pagingClass	: "bottomPaging",
						innerWindow	: 1,
						left		: 1,
						right		: 1
					} ]
				]
			};
			var userList = new List('user-list', options);
			
			$('#filter-online').on('click',function() {
				$('ul.filter li').removeClass('active');
				$(this).parent('li').addClass('active');
				userList.filter(function(item) {
					if (item.values().sl_status == "activo") {
						return true;
					} else {
						return false;
					}
				});
				return false;
			});
			$('#filter-offline').on('click',function() {
				$('ul.filter li').removeClass('active');
				$(this).parent('li').addClass('active');
				userList.filter(function(item) {
					if (item.values().sl_status == "inactivo") {
						return true;
					} else {
						return false;
					}
				});
				return false;
			});
			$('#filter-none').on('click',function() {
				$('ul.filter li').removeClass('active');
				$(this).parent('li').addClass('active');
				userList.filter();
				return false;
			});
			
			$('#user-list').on('click','.sort',function(){
					$('.sort').parent('li').removeClass('active');
					if($(this).parent('li').hasClass('active')) {
						$(this).parent('li').removeClass('active');
					} else {
						$(this).parent('li').addClass('active');
					}
				}
			);
		}
	};
	
	//* gallery grid
    gebo_gal_grid = {
        small: function() {
            //* small gallery grid
            $('#small_grid ul').imagesLoaded(function() {
                // Prepare layout options.
                var options = {
                  autoResize: true, // This will auto-update the layout when the browser window is resized.
                  container: $('#small_grid'), // Optional, used for some extra CSS styling
                  offset: 6, // Optional, the distance between grid items
                  itemWidth: 120, // Optional, the width of a grid item (li)
                  flexibleItemWidth: true
                };
                
                // Get a reference to your grid items.
                var handler = $('#small_grid ul li');
                
                // Call the layout function.
                handler.wookmark(options);
                
                $('#small_grid ul li > a').attr('rel', 'calendar').colorbox({
                    maxWidth	: '80%',
                    maxHeight	: '80%',
                    opacity		: '0.8', 
                    loop		: false,
                    fixed		: true
                });
            });
        }
    };
	
	//* calendar
	gebo_calendar = {
		init: function() {
			var date = new Date();
			var d = date.getDate();
			var m = date.getMonth();
			var y = date.getFullYear();
			var calendar = $('#calendar').fullCalendar({
				header: {
					left: 'prev,next',
					center: 'title,today',
					right: 'month,agendaWeek,agendaDay'
				},
				buttonText: {
					prev: '<i class="icon-chevron-left cal_prev" />',
					next: '<i class="icon-chevron-right cal_next" />'
				},
				aspectRatio: 1.5,
				selectable: true,
				selectHelper: true,
				select: function(start, end, allDay) {
					var title = prompt('Event Title:');
					if (title) {
						calendar.fullCalendar('renderEvent',
							{
								title: title,
								start: start,
								end: end,
								allDay: allDay
							},
							true // make the event "stick"
						);
					}
					calendar.fullCalendar('unselect');
				},
				editable: true,
				theme: false,
				events: [
					{
						title: 'All Day Event',
						start: new Date(y, m, 1),
                                                color: '#aedb97',
                                                textColor: '#3d641b'
					},
					{
						title: 'Long Event',
						start: new Date(y, m, d-5),
						end: new Date(y, m, d-2)
					},
					{
						id: 999,
						title: 'Repeating Event',
						start: new Date(y, m, d+8, 16, 0),
						allDay: false
					},
					{
						id: 999,
						title: 'Repeating Event',
						start: new Date(y, m, d+15, 16, 0),
						allDay: false
					},
					{
						title: 'Meeting',
						start: new Date(y, m, d+12, 15, 0),
						allDay: false,
                                                color: '#aedb97',
                                                textColor: '#3d641b'
					},
					{
						title: 'Lunch',
						start: new Date(y, m, d, 12, 0),
						end: new Date(y, m, d, 14, 0),
						allDay: false
					},
					{
						title: 'Birthday Party',
						start: new Date(y, m, d+1, 19, 0),
						end: new Date(y, m, d+1, 22, 30),
						allDay: false,
                                                color: '#cea97e',
                                                textColor: '#5e4223'
					},
					{
						title: 'Click for Google',
						start: new Date(y, m, 28),
						end: new Date(y, m, 29),
						url: 'http://google.com/'
					}
				],
				eventColor: '#bcdeee'
			})
		}
	};
	
    //* responsive tables
    gebo_media_table = {
        init: function() {
			$('.mediaTable').mediaTable();
        }
    };

</script>
<?php
include('include/sidebar.php');
//include('include/html-footer.php');
?>
