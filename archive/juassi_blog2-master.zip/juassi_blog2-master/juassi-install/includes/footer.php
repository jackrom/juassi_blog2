<footer>
			<div class="container">
				<p>Powered by <a href="http://www.juassi.org/juassi-blog" title="Open Source Blog System">juassi-Blog</a> Version 2.0<br> Copyright &copy; 2013 <a href="http://www.juassi.com/" title="Software Development Company">Juassi Studios</a></p>
			</div>
		</footer>

	</body>
</html>